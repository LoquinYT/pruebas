<!DOCTYPE html>
<html lang=es>
  <head>
    <meta charset="UTF-8">
    <title>Ruffle</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="content">
    <!-- <font color="#2C006C"> -->
      <h1><font face="sans-serif">UP Ruffle</font></h1>
        <header>
		<div class="wrapper">
			<div class="logo"><center>Up Ruffle</center></div>
			
			<nav>
				<a href="index.php">Inicio</a>
				<a href="#">Juegos</a>
				<a href="#">Proyectos</a>
				<a href="#">Contacto</a>
			</nav>
		</div>
	</header>
      <br><br>
      <div class="player">
        <embed src="https://ogwp.ogwpd.tk/html5-snake/index.html"></embed>
        <!-- <object>
  	      <param name="movie" value="">
  	      <embed src="http://flg.l64.rf.gd/files/snake/index.html"></embed>
        </object> -->
      </div>
      <br>
      <p>©2013 Jason D. Straughan - <button>Haz click para jugar!</button></p>
      <!-- </font> -->
    </div>
    <br>
  <!-- flash -->
    <footer>
      <p>Programmed by <a href="https://www.youtube.com/channel/UCCg-PF_wRtZDVsSCF7D2ayA?">LoquinYT</a> & <a href="https://lucas64.tk">Lucas</a></p>
      <p>Under [license] - <a href="https://github.com/ogwp/upruffle">Source Code</a></p>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html>