<!DOCTYPE html>
<html lang=es>
  <head>
    <meta charset="UTF-8">
    <title>Ruffle | Register</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  <imput type="text" placeholder="Correo electrónico">



  </body>